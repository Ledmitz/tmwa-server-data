<?xml version="1.0" encoding="UTF-8"?>
<tileset name="woodland_indoor_x3" tilewidth="32" tileheight="96">
 <image source="../graphics/tiles/woodland_indoor_x3.png" width="512" height="288"/>
</tileset>
