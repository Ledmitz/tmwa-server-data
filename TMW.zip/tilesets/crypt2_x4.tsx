<?xml version="1.0" encoding="UTF-8"?>
<tileset name="crypt2_x4" tilewidth="32" tileheight="96">
 <image source="../graphics/tiles/crypt2_x4.png" width="384" height="192"/>
</tileset>
