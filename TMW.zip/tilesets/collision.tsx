<?xml version="1.0" encoding="UTF-8"?>
<tileset name="collision" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/collision.png" width="64" height="32"/>
</tileset>
