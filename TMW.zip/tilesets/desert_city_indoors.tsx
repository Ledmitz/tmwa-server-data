<?xml version="1.0" encoding="UTF-8"?>
<tileset name="desert_city_indoors" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/desert_city_indoors.png" width="480" height="320"/>
</tileset>
