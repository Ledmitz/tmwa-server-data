<?xml version="1.0" encoding="UTF-8"?>
<tileset name="mushrooms" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/mushrooms.png" width="640" height="224"/>
</tileset>
