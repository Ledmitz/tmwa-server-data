<?xml version="1.0" encoding="UTF-8"?>
<tileset name="desert_x5" tilewidth="32" tileheight="160">
 <image source="../graphics/tiles/desert_x5.png" width="192" height="160"/>
</tileset>
