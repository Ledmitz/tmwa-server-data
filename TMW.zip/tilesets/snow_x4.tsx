<?xml version="1.0" encoding="UTF-8"?>
<tileset name="snow_x4" tilewidth="32" tileheight="128">
 <image source="../graphics/tiles/snow_x4.png" width="128" height="128"/>
</tileset>
